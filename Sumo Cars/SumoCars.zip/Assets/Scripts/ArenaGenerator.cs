using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArenaGenerator : MonoBehaviour {

    private MeshFilter _meshFilter;

    private void Awake() {
        _meshFilter = GetComponent<MeshFilter>();
    }

    void Start() {
    }


    void Update() {
    }

    public void GenerateArenaMesh() {

      
    }
}